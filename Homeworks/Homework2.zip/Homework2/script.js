// #1

// let rangeStart = +prompt("Range Start");
// let rangeEnd = +prompt("Range End");

// for (let i = rangeStart; i <= rangeEnd; i++) {
//     if (i % 2 == 0) {
//         console.log(i);
//     }
// }

// #2

// const randNum = Math.floor(Math.random() * 10 + 1);

// let num = -10;

// while (num != randNum) {
//     if (num == -10) {
//         alert("Guess the number from 1 to 10");
//     } else if (num > randNum) {
//         alert("Lower");
//     } else if (num < randNum) {
//         alert("Higher");
//     }

//     num = +prompt("Number");
// }

// alert("You Won!");
